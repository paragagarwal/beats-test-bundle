package com.couchbase.loader.client;


import java.util.Random;
import net.spy.memcached.internal.OperationFuture;
import com.couchbase.client.CouchbaseClient;

/*
 * Module that runs delete operations
 */

public class Deletes {
	
	static Random generator = new Random( 19580427 );
	static Logging logger=null; 
 
    public static void del_items (CouchbaseClient client, Variables V, String _prefix) {
        int items_to_delete = (int)(V.getDelRatio() * V.getItemCount());
        for (int i=0; i<items_to_delete; i++) {
            String key = String.format("%s%d", _prefix, i);
            OperationFuture<Boolean> delOp = null;
            try {
                delOp = client.delete(key);
            } catch (Exception e) {
                // TODO: Handle error that occurred during deleting?
                continue;
            }
            try {
                if (delOp.get().booleanValue()) {
                    // TODO: Something I'd guess, as deleted item still exists
                }
            } catch (Exception e) {
                // e.printStackTrace();
            }
        }
    }
    
    public static void del_items (CouchbaseClient client[], String[] clientNames,Variables V, String _prefix,String dir,String logName) {
    	 int items_to_delete = (int)(V.getDelRatio() * V.getItemCount());
         if(logger==null){
        	logger = new Logging(dir,logName,"DELETE_LOG");
        }
         for (int i=0; i<items_to_delete; i++) {
            String key = String.format("%s%d", _prefix, i);
            OperationFuture<Boolean> delOp = null;
            try {
            	   int r = generator.nextInt(Integer.MAX_VALUE);
            	   int clientIndex=r%client.length;
                   delOp = client[clientIndex].delete(key);
                   logger.write(clientNames[clientIndex], "OPS_DELETE", key, "NO VALUE");
            } catch (Exception e) {
                // TODO: Handle error that occurred during deleting?
                continue;
            }
            try {
                if (delOp.get().booleanValue()) {
                    // TODO: Something I'd guess, as deleted item still exists
                }
            } catch (Exception e) {
                // e.printStackTrace();
            }
        }
    }
}
