package com.couchbase.loader.client;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.codehaus.jettison.json.JSONException;

import net.spy.memcached.internal.OperationFuture;

import com.couchbase.client.CouchbaseClient;

/*
 * Module that runs set operations, and sets with expires
 */

public class Sets {
	static Random generator = new Random(987654321);
	static Logging logger=null; 
    public static void set_items (CouchbaseClient client, Variables V, String _prefix) throws JSONException {
        Random gen = new Random(987654321);
        int items_to_expire = (int)(V.getExpRatio() * V.getItemCount());
        List<OperationFuture<Boolean>> sets = new LinkedList<OperationFuture<Boolean>>();
        for (int i=0; i<(V.getItemCount() - items_to_expire); i++) {
            OperationFuture<Boolean> setOp;
            String key = String.format("%s%d", _prefix, i);
            if (V.isJson()) {
                setOp = client.set(key, Gen.retrieveJSON(gen, V).toString());
            } else {
                setOp = client.set(key, Gen.retrieveBinary(V));
            }
            if (V.isCheckEnabled()) {
                sets.add(setOp);
            }
        }

        for (int i=(V.getItemCount() - items_to_expire); i<V.getItemCount(); i++) {
            OperationFuture<Boolean> setOp;
            String key = String.format("%s%d", _prefix, i);
            if (V.isJson()) {
                setOp = client.set(key, V.getExpiration(), Gen.retrieveJSON(gen, V).toString());
            } else {
                setOp = client.set(key, V.getExpiration(), Gen.retrieveBinary(V));
            }
            if (V.isCheckEnabled()) {
                sets.add(setOp);
            }
        }

        while (!sets.isEmpty()) {
            try {
                if (sets.get(0).get().booleanValue() == false) {
                    // TODO: Something I'd guess, as set failed
                }
            } catch (Exception e) {
                // e.printStackTrace();
            }
            sets.remove(0);
        }
    }
    
    public static void set_items (CouchbaseClient[] client, String[] clientNames, Variables V, String _prefix,String dir,String logName) throws JSONException {
    	int items_to_expire = (int)(V.getExpRatio() * V.getItemCount());     
    	Random gen = new Random(987654321);
        if(logger==null){
        	logger = new Logging(dir,logName,"SET_EXPIRE_LOG");
        }
       
        List<OperationFuture<Boolean>> sets = new LinkedList<OperationFuture<Boolean>>();
        
        for (int i=0; i<(V.getItemCount() - items_to_expire); i++) {
            OperationFuture<Boolean> setOp;
            String key = String.format("%s%d", _prefix, i);
            int r = generator.nextInt(Integer.MAX_VALUE);
      	   int clientIndex=r%client.length;
      	   logger.write(clientNames[clientIndex], "OPS_SET_INITAL_LOAD", key, "NO VALUE");
            if (V.isJson()) {
                setOp = client[clientIndex].set(key, Gen.retrieveJSON(gen, V).toString());
            } else {
                setOp = client[clientIndex].set(key, Gen.retrieveBinary(V));
            }
            if (V.isCheckEnabled()) {
                sets.add(setOp);
            }
        }

        for (int i=(V.getItemCount() - items_to_expire); i<V.getItemCount(); i++) {
            OperationFuture<Boolean> setOp;
            String key = String.format("%s%d", _prefix, i);
            int r = generator.nextInt(Integer.MAX_VALUE);
      	   int clientIndex=r%client.length;
      	   logger.write(clientNames[clientIndex], "OPS_SET_INITAL_LOAD", key, "NO VALUE");
            if (V.isJson()) {
                setOp = client[clientIndex].set(key, V.getExpiration(), Gen.retrieveJSON(gen, V).toString());
            } else {
                setOp = client[clientIndex].set(key, V.getExpiration(), Gen.retrieveBinary(V));
            }
            if (V.isCheckEnabled()) {
                sets.add(setOp);
            }
        }

        while (!sets.isEmpty()) {
            try {
                if (sets.get(0).get().booleanValue() == false) {
                    // TODO: Something I'd guess, as set failed
                }
            } catch (Exception e) {
                // e.printStackTrace();
            }
            sets.remove(0);
        }
    }
}
