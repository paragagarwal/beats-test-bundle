package com.couchbase.loader.client;

import java.util.Date;
import java.util.Random;

import com.couchbase.client.CouchbaseClient;

/*
 * Module that runs get operations
 */

public class Gets {
	static Random generator = new Random( 19580427 );
	static Logging logger=null; 
    public static void get_items (CouchbaseClient client, Variables V, String _prefix) {
        boolean checkFlag = true;
        int count;
        if (V.getSetRatio() == 0.0) {
            count = V.getItemCount();
        } else {
            count = (int)(((1.0 - V.getSetRatio()) * V.getItemCount()) / V.getSetRatio());
        }
        while (checkFlag) {
            for (int i=0; i<V.getItemCount(); i++) {
                if (count == 0) {
                    checkFlag = false;
                    break;
                }
                Object item = client.get(String.format("%s%d", _prefix, i));
                if (item != null)
                    count --;
            }
        }
    }
    public static void get_items (CouchbaseClient[] client, String[] clientNames,Variables V, String _prefix,String dir,String logName) {
       // if(logger==null){
       // 	logger = new Logging(dir,logName,"OPS_GET_LOG");
      //  }
        Date dt1=new Date();
        Random keyChoiceGen = new Random( dt1.getTime() );
        for (int i=0; i<V.get_readCount(); i++) {
        	   int choice=keyChoiceGen.nextInt(V.get_readCount());
               int r = generator.nextInt(Integer.MAX_VALUE);
         	   int clientIndex=r%client.length;
                Object item = client[clientIndex].get(String.format("%s%d", _prefix, choice));
               // String read="READ";
               // if(item==null){
                //  read="DATA NOT PRESENT";
               // }
               // logger.write(clientNames[clientIndex], "OPS_GET", String.format("%s%d", _prefix, i), read);    
        }
    }
}
