package com.couchbase.loader.client;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import net.spy.memcached.internal.OperationFuture;

import com.couchbase.client.CouchbaseClient;

/*
 * Module that runs append and prepend operations
 */

public class Mods {
	static Random generator = new Random( 19580427 );
	static Logging logger=null; 
    public static void mod_items (CouchbaseClient client, Variables V, String _prefix) {
        int point_of_reference = (int)(V.getDelRatio() * V.getItemCount());
        int items_to_append = (int)(V.getAppendRatio() * V.getItemCount());
        int items_to_prepend = (int)(V.getPrependRatio() * V.getItemCount());

        List<OperationFuture<Boolean>> mods = new LinkedList<OperationFuture<Boolean>>();
        for (int i=point_of_reference; i<items_to_append; i++) {
            OperationFuture<Boolean> appendOp;
            String key = String.format("%s%d", _prefix, i);
            appendOp = client.append(key, Gen.retrieveTandem(V, "append"));
            if (V.isCheckEnabled()) {
                mods.add(appendOp);
            }
        }

        for (int i=point_of_reference; i<items_to_prepend; i++) {
            OperationFuture<Boolean> prependOp;
            String key = String.format("%s%d", _prefix, i);
            prependOp = client.prepend(key, Gen.retrieveTandem(V, "prepend"));
            if (V.isCheckEnabled()) {
                mods.add(prependOp);
            }
        }

        while (!mods.isEmpty()) {
            try {
                if (mods.get(0).get().booleanValue() == false) {
                    // TODO: Something I'd guess, as mod failed
                }
            } catch (Exception e) {
                // e.printStackTrace();
            }
            mods.remove(0);
        }
    }
    
    
    public static void mod_items (CouchbaseClient[] client, String[] clientNames,Variables V, String _prefix,String dir,String logName) {
    	 int point_of_reference = (int)(V.getDelRatio() * V.getItemCount());
         int items_to_append = (int)(V.getAppendRatio() * V.getItemCount());
         int items_to_prepend = (int)(V.getPrependRatio() * V.getItemCount());

        if(logger==null){
        	logger = new Logging(dir,logName,"SET_APPEND_PREPEND_LOG");
        }
        
        List<OperationFuture<Boolean>> mods = new LinkedList<OperationFuture<Boolean>>();
        for (int i=point_of_reference; i<items_to_append; i++) {
            OperationFuture<Boolean> appendOp;
            String key = String.format("%s%d", _prefix, i);
            int r = generator.nextInt(Integer.MAX_VALUE);
     	    int clientIndex=r%client.length;
            appendOp = client[clientIndex].append(key, Gen.retrieveTandem(V, "append"));
            logger.write(clientNames[clientIndex], "SET_APPEND", key, "NO VALUE");
            if (V.isCheckEnabled()) {
                mods.add(appendOp);
            }
        }

        for (int i=point_of_reference; i<items_to_append; i++) {
            OperationFuture<Boolean> prependOp;
            String key = String.format("%s%d", _prefix, i);
            int r = generator.nextInt(Integer.MAX_VALUE);
     	    int clientIndex=r%client.length;
            prependOp = client[clientIndex].prepend(key, Gen.retrieveTandem(V, "prepend"));
            logger.write(clientNames[clientIndex], "SET_PREPEND", key, "NO VALUE");
            if (V.isCheckEnabled()) {
                mods.add(prependOp);
            }
        }

        while (!mods.isEmpty()) {
            try {
                if (mods.get(0).get().booleanValue() == false) {
                    // TODO: Something I'd guess, as mod failed
                }
            } catch (Exception e) {
                // e.printStackTrace();
            }
            mods.remove(0);
        }
    }
}
