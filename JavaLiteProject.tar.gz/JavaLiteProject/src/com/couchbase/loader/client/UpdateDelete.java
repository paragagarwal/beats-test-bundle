package com.couchbase.loader.client;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import net.spy.memcached.internal.OperationFuture;

import com.couchbase.client.CouchbaseClient;

public class UpdateDelete {
	static Date date = new Date();
	static Random generator = new Random( date.getTime() );
	static Logging logger=null; 
	
	public static void update_del_items (CouchbaseClient client[], String[] clientNames,Variables V, String _prefix,String dir,String logName) {
   	    
		List<OperationFuture<Boolean>> mods = new LinkedList<OperationFuture<Boolean>>();
		if(logger==null){
			logger = new Logging(dir,logName,"UPDATE_DELETE_LOG");
        }
		
        int count = 0;
        
        Date dt1=new Date();
        int totalCount=V.get_endUpdateDeleteCount()-V.get_startUpdateDeleteCount();
        Random keyChoiceGen = new Random( dt1.getTime() );
        Random actionChoiceGen = new Random( dt1.getTime() );
        
        for(int i=0;i< totalCount;++i) {
           count++;
           int choice = V.get_startUpdateDeleteCount()+actionChoiceGen.nextInt(totalCount);
           int doThis = keyChoiceGen.nextInt(2);
           String key = String.format("%s%d", _prefix, choice);
           
           if(doThis == 0){
	           OperationFuture<Boolean> delOp = null;
	           try {
	           	   int r = generator.nextInt(Integer.MAX_VALUE);
	           	   int clientIndex=r%client.length;
	               delOp = client[clientIndex].delete(key);
	               logger.write(clientNames[clientIndex], "DEL", key, "NO VALUE");
	           } catch (Exception e) {
	               // TODO: Handle error that occurred during deleting?
	               continue;
	           }
	           
	           
	           try {
	               if (delOp.get().booleanValue()) {
	                   // TODO: Something I'd guess, as deleted item still exists
	               }
	           } catch (Exception e) {
	               // e.printStackTrace();
	           }
	           
           }else if(doThis == 1){
        	       
        	   OperationFuture<Boolean> delOp = null;
	           try {
	           	   int r = generator.nextInt(Integer.MAX_VALUE);
	           	   int clientIndex=r%client.length;
	                  delOp = client[clientIndex].delete(key);
	                  logger.write(clientNames[clientIndex], "DEL", key, "NO VALUE");
	           } catch (Exception e) {
	               // TODO: Handle error that occurred during deleting?
	               continue;
	           }
	           
	           
	           try {
	               if (delOp.get().booleanValue()) {
	                   // TODO: Something I'd guess, as deleted item still exists
	               }
	           } catch (Exception e) {
	               // e.printStackTrace();
	           }
	           
        	       OperationFuture<Boolean> appendOp;
                   int r = generator.nextInt(Integer.MAX_VALUE);
            	   int clientIndex=r%client.length;
                   appendOp = client[clientIndex].append(key, Gen.retrieveTandem(V, "append"));
                   logger.write(clientNames[clientIndex], "APP", key, "NO VALUE");
                   if (V.isCheckEnabled()) {
                       mods.add(appendOp);
                   }
                   OperationFuture<Boolean> prependOp;
                   r = generator.nextInt(Integer.MAX_VALUE);
            	   clientIndex=r%client.length;
                   prependOp = client[clientIndex].prepend(key, Gen.retrieveTandem(V, "prepend"));
                   logger.write(clientNames[clientIndex], "PRE", key, "NO VALUE");
                   if (V.isCheckEnabled()) {
                       mods.add(prependOp);
                   }
                   
                   
           }else{
        	   
        	   OperationFuture<Boolean> appendOp;
               int r = generator.nextInt(Integer.MAX_VALUE);
        	   int clientIndex=r%client.length;
               appendOp = client[clientIndex].append(key, Gen.retrieveTandem(V, "append"));
               logger.write(clientNames[clientIndex], "APP", key, "NO VALUE");
               if (V.isCheckEnabled()) {
                   mods.add(appendOp);
               }
               OperationFuture<Boolean> prependOp;
               r = generator.nextInt(Integer.MAX_VALUE);
        	   clientIndex=r%client.length;
               prependOp = client[clientIndex].prepend(key, Gen.retrieveTandem(V, "prepend"));
               logger.write(clientNames[clientIndex], "PRE", key, "NO VALUE");
               if (V.isCheckEnabled()) {
                   mods.add(prependOp);
               }
              
           }
       }
        
       
   }
	
	
}
