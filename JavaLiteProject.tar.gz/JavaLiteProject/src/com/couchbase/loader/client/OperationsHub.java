package com.couchbase.loader.client;

import java.util.Date;
import java.text.SimpleDateFormat;

import com.couchbase.client.CouchbaseClient;

public class OperationsHub {
    public static void runClientOperations(final CouchbaseClient client, final Variables V,
            final String _prefix) throws InterruptedException {

        Runnable _sets_ = new Runnable() {
            public void run() {
                // System.out.println("Sets thread starts");
                try {
                    Sets.set_items(client, V, _prefix);
                } catch (Exception e) {
                    // e.printStackTrace();
                }
            }
        };

        Runnable _gets_ = new Runnable() {
            public void run() {
                // System.out.println("Gets thread starts");
                try {
                    Gets.get_items(client, V, _prefix);
                } catch (Exception e) {
                    // e.printStackTrace();
                }
            }
        };

        Runnable _mods_ = new Runnable() {
            public void run() {
                // System.out.println("Mods thread starts");
                try {
                    Mods.mod_items(client, V, _prefix);
                } catch (Exception e) {
                    // e.printStackTrace();
                }
            }
        };

        Runnable _adds_ = new Runnable() {
            public void run() {
                // System.out.println("Adds thread starts");
                try {
                    Adds.add_items(client, V, _prefix);
                } catch (Exception e) {
                    // e.printStackTrace();
                }
            }
        };

        Runnable _dels_ = new Runnable() {
            public void run() {
                // System.out.println("Deletes thread starts");
                try {
                    Deletes.del_items(client, V, _prefix);
                } catch (Exception e) {
                    // e.printStackTrace();
                }
            }
        };

        Thread _sets = new Thread(_sets_);
        Thread _gets = new Thread(_gets_);
        Thread _mods = new Thread(_mods_);
        Thread _adds = new Thread(_adds_);
        Thread _dels = new Thread(_dels_);

        _sets.start();      //Begin sets thread
        _gets.start();      //Begin gets thread
        _sets.join();       //Wait for sets thread to complete
        _dels.start();      //Begin deletes thread
        _mods.start();      //Begin mods thread
        _adds.start();      //Begin adds thread
        _dels.join();       //Wait for deletes thread to complete
        _adds.join();       //Wait for adds thread to complete
        _mods.join();       //Wait for mods thread to complete
        _gets.join();       //Wait for gets thread to complete
        client.shutdown();

    }
    
    public static void runClientOperations(final CouchbaseClient[] client,final String[] clientNames, final Variables V,
            final String _prefix,final String dir,final String logPrefix) throws InterruptedException {
    	final Date dt = new Date();
    	final SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
    	sdf.format(dt);
        Runnable _sets_ = new Runnable() {
            public void run() {
                // System.out.println("Sets thread starts");
                try {
                    Sets.set_items(client, clientNames,V, _prefix,dir,logPrefix+"_"+sdf.format(dt)+"_SET_EXPIRE.log");
                } catch (Exception e) {
                    // e.printStackTrace();
                }
            }
        };

        Runnable _gets_ = new Runnable() {
            public void run() {
                // System.out.println("Gets thread starts");
                try {
                    Gets.get_items(client,clientNames, V, _prefix,dir,logPrefix+"_"+sdf.format(dt)+"_GETS.log");
                } catch (Exception e) {
                    // e.printStackTrace();
                }
            }
        };

        Runnable _mods_ = new Runnable() {
            public void run() {
                // System.out.println("Mods thread starts");
                try {
                    Mods.mod_items(client,clientNames, V, _prefix,dir,logPrefix+"_"+sdf.format(dt)+"_SET_APPEND.log");
                } catch (Exception e) {
                    // e.printStackTrace();
                }
            }
        };

        Runnable _adds_ = new Runnable() {
            public void run() {
                // System.out.println("Adds thread starts");
                try {
                	Adds.add_items(client,clientNames,V, _prefix,dir,logPrefix+"_"+sdf.format(dt)+"_ADD.log");
                } catch (Exception e) {
                    // e.printStackTrace();
                }
            }
        };
        
        Runnable _dels_ = new Runnable() {
            public void run() {
                // System.out.println("Deletes thread starts");
                try {
                    Deletes.del_items(client, clientNames,V, _prefix,dir,logPrefix+"_"+sdf.format(dt)+"_DELETES.log");
                } catch (Exception e) {
                    // e.printStackTrace();
                }
            }
        };

        Runnable _updatedeletes_ = new Runnable() {
            public void run() {
                // System.out.println("Deletes thread starts");
                try {
                    UpdateDelete.update_del_items(client, clientNames,V, _prefix,dir,logPrefix+"_"+sdf.format(dt)+"_UPDATE_DELETES.log");
                } catch (Exception e) {
                    // e.printStackTrace();
                }
            }
        };

        Thread _sets = new Thread(_sets_);
        Thread _gets = new Thread(_gets_);
        Thread _updateDeletes = new Thread(_updatedeletes_);
        Thread _mods =new Thread(_mods_);
        Thread _adds =new Thread(_adds_);
        // Initial load the data
        _sets.start();      //Begin sets thread
        _sets.join();       //Wait for sets thread to complete
        _gets.start();      //Begin gets thread
        _updateDeletes.start(); // Begin the Update delete thread
        _updateDeletes.join(); // Wait for update Delete to finish
        _mods.start(); // Begin the Update delete thread
        _mods.join(); // Wait for update Delete to finish
        _adds.start(); //Begin the add thread
        _adds.join();  //Wait for gets thread to complete
        _gets.join();  //Wait for gets thread to complete
        
        for(int i=0;i<client.length;++i){
        	System.out.println(" Shutting down Client "+clientNames[i]);
        	client[i].shutdown();
        }

    }
}
