package com.couchbase.loader.client;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Logging {
	Logger logger;  
	FileHandler fh; 
	public Logging(String dir,String fileName,String loggerName){
		    logger = Logger.getLogger(loggerName); 

		    try {  
		        // This block configure the logger with handler and formatter  
		        fh = new FileHandler(dir+"/"+fileName);  
		        logger.addHandler(fh);

		        BriefFormatter formatter = new BriefFormatter();
		        fh.setFormatter(formatter);  
		        for(Handler iHandler:logger.getParent().getHandlers()){
		       		logger.getParent().removeHandler(iHandler);
		        }
		    } catch (SecurityException e) {  
		        e.printStackTrace();  
		    } catch (IOException e) {  
		        e.printStackTrace();  
		    }  

		    logger.info("Starting Logging");  

	}
	
	public void write(String message){
		 Date dt = new Date();
    	 SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
         sdf.format(dt);
      
		logger.info("["+sdf.format(dt)+"] "+message);
	}
	
	public void write(
			String ip,
			String operation,
			String key,
			String value){
		StringBuilder sb = new StringBuilder();
		sb.append("I="+ip);
		sb.append(",");
		sb.append("O="+operation);
		sb.append(",");
		sb.append("K="+key);
		sb.append(",");
		sb.append(value);
	    write(sb.toString());
	}
	
	public void close(){
		logger.info("End Logging");  
		fh.close();
	}
	
	private class BriefFormatter extends Formatter 
	{   
	    public BriefFormatter() { super(); }

	    @Override 
	    public String format(final LogRecord record) 
	    {
	        return "\n"+record.getMessage();
	    }   
	}
}
