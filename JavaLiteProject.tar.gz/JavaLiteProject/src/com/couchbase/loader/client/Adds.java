package com.couchbase.loader.client;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.codehaus.jettison.json.JSONException;

import net.spy.memcached.internal.OperationFuture;

import com.couchbase.client.CouchbaseClient;

/*
 * Module that runs add operations
 */

public class Adds {
	static Random generator = new Random( 19580427 );
	static Logging logger=null; 
    public static void add_items (CouchbaseClient client, Variables V, String _prefix) throws JSONException {
        Random gen = new Random(123456789);
        List<OperationFuture<Boolean>> adds = new LinkedList<OperationFuture<Boolean>>();
        for (int i=V.getItemCount(); i<(V.getItemCount() + V.getAddCount()); i++) {
            OperationFuture<Boolean> addOp;
            String key = String.format("%s%d", _prefix, i);
            if (V.isJson()) {
                addOp = client.add(key, Gen.retrieveJSON(gen, V).toString());
            } else {
                addOp = client.add(key, Gen.retrieveBinary(V));
            }
            if (V.isCheckEnabled()) {
                adds.add(addOp);
            }
        }

        while (!adds.isEmpty()) {
            try {
                if (adds.get(0).get().booleanValue() == false) {
                    // TODO: Something I'd guess, as add failed
                }
            } catch (Exception e) {
                // e.printStackTrace();
            }
            adds.remove(0);
        }
    }
    
    public static void add_items (CouchbaseClient[] client, String[] clientNames,Variables V,String _prefix,String dir,String logName) throws JSONException {
        Random gen = new Random(123456789);
        if(logger==null){
        	logger = new Logging(dir,logName,"ADD_LOG");
        }
        List<OperationFuture<Boolean>> adds = new LinkedList<OperationFuture<Boolean>>();
        for (int i=V.getItemCount(); i<(V.getItemCount() + V.getAddCount()); i++) {
            OperationFuture<Boolean> addOp;
            String key = String.format("%s%d", _prefix, i);
            int r = generator.nextInt(Integer.MAX_VALUE);
     	    int clientIndex=r%client.length;
            if (V.isJson()) {
                addOp = client[clientIndex].add(key, Gen.retrieveJSON(gen, V).toString());
            } else {
                addOp = client[clientIndex].add(key, Gen.retrieveBinary(V));
            }
            logger.write(clientNames[clientIndex], "A", key, "NO VALUE");
            if (V.isCheckEnabled()) {
                adds.add(addOp);
            }
        }

        while (!adds.isEmpty()) {
            try {
                if (adds.get(0).get().booleanValue() == false) {
                    // TODO: Something I'd guess, as add failed
                }
            } catch (Exception e) {
                // e.printStackTrace();
            }
            adds.remove(0);
        }
    }
}
